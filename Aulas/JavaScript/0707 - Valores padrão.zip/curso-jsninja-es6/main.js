const exp = (x, y = 2) => x * y;

console.log(exp(2, 8));
