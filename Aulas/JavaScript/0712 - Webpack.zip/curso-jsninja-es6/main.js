import { soma } from "./matematica";

const res = soma(1, 2);
console.log(res);
