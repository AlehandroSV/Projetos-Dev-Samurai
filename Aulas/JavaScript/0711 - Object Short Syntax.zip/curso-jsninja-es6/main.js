const nome = "Felipe";
const idade = 39;

const convidado = {
  nome,
  idade,
  endereco: "Av X, 39"
};

console.log(convidado);
