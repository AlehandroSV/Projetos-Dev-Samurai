"use strict";

var nome = "Felipe";
var idade = 39;
var convidado = {
  nome: nome,
  idade: idade,
  endereco: "Av X, 39"
};
console.log(convidado);
