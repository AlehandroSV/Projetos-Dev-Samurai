# Eventos inline

- [x] O que são eventos?
  - Uma resposta da interface para um estímulo
- [x] Como adicionar eventos a objetos
