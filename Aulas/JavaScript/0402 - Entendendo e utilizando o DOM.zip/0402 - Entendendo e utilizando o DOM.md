# Entendendo e utilizando o DOM

- [x] Formas de utilizar o DOM
  - Console
  - HTML
- [x] Como utilizar um objeto da árvore
  - `document.getElementById()` - recupera-se com o '#'
  - `document.getElementsByClassName()` - recupera-se sem o '.'
  - `document.getElementsByTagName()`
- [x] Alterando um atributo
  - `innerText`
    - `document.getElementById().htmlText = '<b>Hello</b>'`
  - `style`
    - `document.getElementById().style.color = 'red'`
