import soma, { algumaOp } from "./matematica/soma";
import subtracao from "./matematica/subtracao";

console.log(soma(1, 2));
console.log(subtracao(1, 2));
