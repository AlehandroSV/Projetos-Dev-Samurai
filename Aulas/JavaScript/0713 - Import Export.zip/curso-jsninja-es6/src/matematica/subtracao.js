export default function subtracao(x, y) {
  return x - y;
}
