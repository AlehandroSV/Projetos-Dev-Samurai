export function algumaOp(x) {
  return x * 2;
}

export default function soma(x, y) {
  return x + y;
}
